# Copyright (c) Microsoft Corporation
# Licensed under the MIT License.

name = 'raiutils'
_major = '0'
_minor = '3'
_patch = '0'
version = '{}.{}.{}'.format(_major, _minor, _patch)
