# Copyright (c) Microsoft Corporation
# Licensed under the MIT License.

# Version will be populated during release from version.cfg file
# by running `yarn auto-version`
version = "0.0.0"
