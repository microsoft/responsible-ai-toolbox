# Copyright (c) Microsoft Corporation
# Licensed under the MIT License.

"""Internal configuration of Responsible AI Model Analysis."""
