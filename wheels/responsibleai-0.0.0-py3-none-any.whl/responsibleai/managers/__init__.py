# Copyright (c) Microsoft Corporation
# Licensed under the MIT License.

"""Contains all of the managers."""
