# Copyright (c) Microsoft Corporation
# Licensed under the MIT License.

"""Counterfactual dashboard schema module."""
