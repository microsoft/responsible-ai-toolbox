# Copyright (c) Microsoft Corporation
# Licensed under the MIT License.

"""Error Analysis dashboard schema module."""
