# Copyright (c) Microsoft Corporation
# Licensed under the MIT License.

"""Causal dashboard schema module."""
